/**
 * DIG THE DATA - Simple & Clean Subterranean Puzzle Game
 * Zero images, pure interactive tactile deduction
 */

(function () {
  'use strict';

  // --- GAME STATE ---
  let currentLevelIndex = 0;
  let score = 0;
  let currentDepth = 15;
  let startTime = null;
  let activeParticles = 0;
  const MAX_PARTICLES = 16;

  // Level-specific puzzle state
  let levelState = {};

  // Team ID from URL query param, parent iframe or local storage
  const urlParams = new URLSearchParams(window.location.search);
  let teamId = urlParams.get('teamId') || localStorage.getItem('dig_the_data_team_id') || 'CYBER_DIGGERS';

  // --- 5 SIMPLE & SATISFYING PUZZLE LEVELS ---
  const LEVELS = [
    // --- LEVEL 1: PROXIMITY RADAR ---
    {
      levelNum: 1,
      name: 'SURFACE SANDS',
      depth: 15,
      gridCols: 5,
      gridRows: 4,
      themeClass: 'theme-stratum-1',
      goalTitle: 'FIND DATA CORE 42',
      hintText: 'Unearthed numbers show distance (1 = right next to it!)',
      initLevel: () => {
        // Target is at a random spot, rest are empty/decoys
        return { targetValue: 42, targetFound: false };
      },
      generateItems: () => {
        // 20 tiles total
        const items = [];
        items.push({ type: 'target_core', value: 42, isTarget: true });
        items.push({ type: 'decoy_core', value: 18 });
        items.push({ type: 'decoy_core', value: 29 });
        while (items.length < 20) {
          items.push({ type: 'clue_tile' });
        }
        return items;
      },
    },

    // --- LEVEL 2: TWIN MATCH ---
    {
      levelNum: 2,
      name: 'MATRIX BEDROCK',
      depth: 45,
      gridCols: 5,
      gridRows: 4,
      themeClass: 'theme-stratum-2',
      goalTitle: 'FIND BOTH TWIN CORES [77]',
      hintText: 'Dig up the 2 matching gold cores (0 of 2 found)',
      initLevel: () => {
        return { matched: 0, required: 2 };
      },
      generateItems: () => {
        const items = [];
        items.push({ type: 'twin_core', value: 77, isTarget: true, id: 1 });
        items.push({ type: 'twin_core', value: 77, isTarget: true, id: 2 });
        items.push({ type: 'decoy_core', value: 34 });
        items.push({ type: 'decoy_core', value: 51 });
        while (items.length < 20) {
          items.push({ type: 'clue_tile' });
        }
        return items;
      },
    },

    // --- LEVEL 3: FOLLOW THE COMPASS ARROWS ---
    {
      levelNum: 3,
      name: 'CORRUPTED STRATA',
      depth: 85,
      gridCols: 6,
      gridRows: 4,
      themeClass: 'theme-stratum-3',
      goalTitle: 'FOLLOW ARROWS TO VAULT CORE 99',
      hintText: 'Arrows point directly toward the hidden core (→, ↓, ↘)',
      initLevel: () => {
        return { targetFound: false };
      },
      generateItems: () => {
        const items = [];
        items.push({ type: 'target_core', value: 99, isTarget: true });
        while (items.length < 24) {
          items.push({ type: 'arrow_tile' });
        }
        return items;
      },
    },

    // --- LEVEL 4: KEY & VAULT PUZZLE ---
    {
      levelNum: 4,
      name: 'CRYPTO VAULT',
      depth: 135,
      gridCols: 6,
      gridRows: 4,
      themeClass: 'theme-stratum-4',
      goalTitle: 'FIND THE KEY TO UNLOCK THE VAULT',
      hintText: 'Step 1: Dig up the Key [🔑]. Step 2: Open the Vault [🔒].',
      initLevel: () => {
        return { hasKey: false, vaultOpened: false };
      },
      generateItems: () => {
        const items = [];
        items.push({ type: 'key_item', isKey: true });
        items.push({ type: 'vault_item', isVault: true, locked: true });
        items.push({ type: 'decoy_core', value: 64 });
        while (items.length < 24) {
          items.push({ type: 'clue_tile' });
        }
        return items;
      },
    },

    // --- LEVEL 5: THE MASTER CORE Ω ---
    {
      levelNum: 5,
      name: 'ABYSSAL MASTER TRENCH',
      depth: 200,
      gridCols: 6,
      gridRows: 5,
      themeClass: 'theme-stratum-5',
      goalTitle: 'ACTIVATE 3 POWER NODES TO UNLOCK MASTER CORE Ω',
      hintText: 'Activate 3 green power nodes [⚡] to disable the shield (0/3)',
      initLevel: () => {
        return { nodesActive: 0, requiredNodes: 3, masterUnlocked: false };
      },
      generateItems: () => {
        const items = [];
        items.push({ type: 'master_core', value: 'Ω', isMaster: true, locked: true });
        items.push({ type: 'power_node', id: 1 });
        items.push({ type: 'power_node', id: 2 });
        items.push({ type: 'power_node', id: 3 });
        while (items.length < 30) {
          items.push({ type: 'clue_tile' });
        }
        return items;
      },
    },
  ];

  // --- DOM ELEMENTS ---
  const elTeamTag = document.getElementById('hud-team-tag');
  const elTargetText = document.getElementById('hud-target-text');
  const elHintText = document.getElementById('hud-hint-text');
  const elScore = document.getElementById('hud-score');
  const elDepth = document.getElementById('hud-depth');
  const elStratumSectorTitle = document.getElementById('stratum-sector-title');
  const elStratumName = document.getElementById('depth-stratum-name');
  const elStratumProgress = document.getElementById('depth-stratum-progress');
  const elDepthBarFill = document.getElementById('depth-bar-fill');
  const elPuzzleStatus = document.getElementById('puzzle-status-text');

  const elViewport = document.getElementById('excavation-viewport');
  const elStrataContainer = document.getElementById('strata-container');
  const elDigGrid = document.getElementById('dig-grid');
  const elDrillRig = document.getElementById('drill-rig');
  const elDrillHintBubble = document.getElementById('drill-hint-bubble');
  const elParticlesLayer = document.getElementById('particles-layer');
  const elToast = document.getElementById('hud-toast');

  // Overlays
  const elOverlayStart = document.getElementById('overlay-start');
  const elInputTeamId = document.getElementById('input-team-id');
  const elBtnStartGame = document.getElementById('btn-start-game');

  const elOverlayLevel = document.getElementById('overlay-level-complete');
  const elLvlTitle = document.getElementById('lvl-success-title');
  const elLvlDesc = document.getElementById('lvl-success-desc');
  const elLvlDepthReached = document.getElementById('lvl-depth-reached');
  const elLvlBonusScore = document.getElementById('lvl-bonus-score');
  const elBtnNextLevel = document.getElementById('btn-next-level');

  const elOverlayVictory = document.getElementById('overlay-victory');
  const elVFinalScore = document.getElementById('v-final-score');
  const elVFinalDepth = document.getElementById('v-final-depth');
  const elVTeamId = document.getElementById('v-team-id');
  const elVTimeTaken = document.getElementById('v-time-taken');
  const elBtnPlayAgain = document.getElementById('btn-play-again');

  // --- INITIALIZE ---
  function init() {
    elInputTeamId.value = teamId;
    updateTeamBadge();

    elBtnStartGame.addEventListener('click', handleStartGame);
    elBtnNextLevel.addEventListener('click', handleNextLevel);
    elBtnPlayAgain.addEventListener('click', handleRestart);

    // Parent iframe messaging
    window.addEventListener('message', (event) => {
      if (!event.data) return;
      if (event.data.type === 'SET_TEAM_ID' && event.data.teamId) {
        teamId = event.data.teamId.toUpperCase();
        elInputTeamId.value = teamId;
        localStorage.setItem('dig_the_data_team_id', teamId);
        updateTeamBadge();
      }
      if (event.data.type === 'START_GAME') {
        handleStartGame();
      }
    });

    try {
      if (window.parent && window.parent !== window) {
        window.parent.postMessage({ type: 'GAME_READY', game: 'game1' }, '*');
      }
    } catch (e) {}
  }

  function updateTeamBadge() {
    elTeamTag.textContent = `TEAM: ${teamId}`;
  }

  function handleStartGame() {
    const raw = elInputTeamId.value.trim();
    if (raw) {
      teamId = raw.toUpperCase();
      localStorage.setItem('dig_the_data_team_id', teamId);
    }
    updateTeamBadge();

    elOverlayStart.classList.remove('active');
    startTime = Date.now();
    currentLevelIndex = 0;
    score = 0;
    loadLevel(currentLevelIndex);
  }

  // --- LOAD LEVEL ---
  function loadLevel(index) {
    const level = LEVELS[index];
    if (!level) {
      showVictory();
      return;
    }

    levelState = level.initLevel();

    // HUD text
    elTargetText.textContent = level.goalTitle;
    elHintText.textContent = level.hintText;
    currentDepth = level.depth;
    elDepth.textContent = `${currentDepth}m`;
    elScore.textContent = score.toLocaleString();
    elStratumSectorTitle.textContent = `SECTOR 0${level.levelNum} // ${level.name}`;
    elStratumName.textContent = `STRATUM ${level.levelNum}: ${level.name}`;
    elStratumProgress.textContent = `LEVEL ${level.levelNum} / ${LEVELS.length}`;
    elDepthBarFill.style.width = `${(level.levelNum / LEVELS.length) * 100}%`;
    elPuzzleStatus.textContent = 'SEARCHING';
    elPuzzleStatus.style.color = '#ffb703';

    // Theme class
    LEVELS.forEach(l => elStrataContainer.classList.remove(l.themeClass));
    elStrataContainer.classList.add(level.themeClass);

    // Grid Setup
    const items = shuffle(level.generateItems());
    elDigGrid.style.gridTemplateColumns = `repeat(${level.gridCols}, 1fr)`;
    elDigGrid.innerHTML = '';

    items.forEach((item, idx) => {
      const cell = document.createElement('div');
      cell.className = 'grid-cell';
      cell.dataset.index = idx;
      cell.dataset.col = (idx % level.gridCols) + 1;
      cell.dataset.row = Math.floor(idx / level.gridCols) + 1;
      cell.itemData = item;

      // What is under the block
      const under = document.createElement('div');
      under.className = 'cell-underground';
      cell.undergroundEl = under;

      // Render non-clue items upfront (cores, keys, nodes)
      renderUndergroundObject(under, item, cell);

      // Soil block on top
      const block = document.createElement('div');
      block.className = 'terrain-block';

      block.addEventListener('click', (e) => {
        e.stopPropagation();
        handleDigBlock(block, cell, item);
      });

      cell.appendChild(under);
      cell.appendChild(block);
      elDigGrid.appendChild(cell);
    });

    // Reset drill position
    positionDrillOver(null);
    elDrillHintBubble.textContent = 'READY';
  }

  // --- RENDER PERMANENT UNDERGROUND OBJECTS ---
  function renderUndergroundObject(under, item, cell) {
    if (item.type === 'target_core' || item.type === 'twin_core' || item.type === 'decoy_core' || item.type === 'master_core') {
      const core = document.createElement('div');
      core.className = 'data-core-item';
      if (item.isTarget) core.classList.add('is-target');
      if (item.isMaster) core.classList.add('is-master');

      const diamond = document.createElement('div');
      diamond.className = 'data-core-diamond';

      const content = document.createElement('div');
      content.className = 'core-content';

      const val = document.createElement('span');
      val.className = 'core-val';
      val.textContent = item.value;

      const tag = document.createElement('span');
      tag.className = 'core-tag';
      tag.textContent = item.isMaster ? 'MASTER Ω' : 'DATA CORE';

      content.appendChild(val);
      content.appendChild(tag);
      core.appendChild(diamond);
      core.appendChild(content);

      core.addEventListener('click', (e) => {
        e.stopPropagation();
        handleCoreClick(item, core, cell);
      });

      under.appendChild(core);
      cell.coreElement = core;

    } else if (item.type === 'key_item') {
      const keyEl = document.createElement('div');
      keyEl.className = 'key-item';
      const icon = document.createElement('span');
      icon.className = 'key-icon';
      icon.textContent = '🔑';
      const lbl = document.createElement('span');
      lbl.className = 'item-label';
      lbl.textContent = 'VAULT KEY';

      keyEl.appendChild(icon);
      keyEl.appendChild(lbl);

      keyEl.addEventListener('click', (e) => {
        e.stopPropagation();
        handleKeyClick(keyEl, cell);
      });

      under.appendChild(keyEl);
      cell.keyElement = keyEl;

    } else if (item.type === 'vault_item') {
      const vaultEl = document.createElement('div');
      vaultEl.className = 'vault-item';
      const icon = document.createElement('span');
      icon.className = 'vault-icon';
      icon.textContent = '🔒';
      const lbl = document.createElement('span');
      lbl.className = 'item-label';
      lbl.textContent = 'LOCKED VAULT';

      vaultEl.appendChild(icon);
      vaultEl.appendChild(lbl);

      vaultEl.addEventListener('click', (e) => {
        e.stopPropagation();
        handleVaultClick(vaultEl, cell);
      });

      under.appendChild(vaultEl);
      cell.vaultElement = vaultEl;

    } else if (item.type === 'power_node') {
      const nodeEl = document.createElement('div');
      nodeEl.className = 'power-node-item';
      const orb = document.createElement('div');
      orb.className = 'power-node-orb';
      const lbl = document.createElement('span');
      lbl.className = 'power-node-label';
      lbl.textContent = `NODE 0${item.id}`;

      nodeEl.appendChild(orb);
      nodeEl.appendChild(lbl);

      nodeEl.addEventListener('click', (e) => {
        e.stopPropagation();
        handlePowerNodeClick(nodeEl, item, cell);
      });

      under.appendChild(nodeEl);
      cell.nodeElement = nodeEl;
    }
  }

  // --- DIGGING ACTION ---
  function handleDigBlock(block, cell, item) {
    if (block.classList.contains('broken')) return;

    // Drill visual
    animateDrillTo(block);

    // Crack and shrink (220ms)
    block.classList.add('cracking');
    spawnParticles(block, 8, getStrataColor());

    setTimeout(() => {
      block.classList.add('broken');
      score += 15;
      updateScoreHUD();

      // If clue tile: render proximity number
      if (item.type === 'clue_tile') {
        renderDistanceClue(cell);
      } else if (item.type === 'arrow_tile') {
        renderArrowClue(cell);
      } else if (item.isTarget) {
        showToast('TARGET DATA CORE EXPOSED! CLICK TO RETRIEVE');
        elDrillHintBubble.textContent = 'FOUND!';
      } else if (item.isKey) {
        showToast('GOLDEN KEY LOCATED! CLICK TO PICK UP');
        elDrillHintBubble.textContent = 'KEY FOUND';
      } else if (item.isVault) {
        showToast('VAULT DISCOVERED!');
      } else if (item.type === 'power_node') {
        showToast(`POWER NODE 0${item.id} EXPOSED! CLICK TO ACTIVATE`);
      }
    }, 220);
  }

  // --- DISTANCE CLUES ---
  function renderDistanceClue(cell) {
    const targetCell = findNearestTargetCell(cell);
    if (!targetCell) return;

    const c1 = parseInt(cell.dataset.col, 10);
    const r1 = parseInt(cell.dataset.row, 10);
    const c2 = parseInt(targetCell.dataset.col, 10);
    const r2 = parseInt(targetCell.dataset.row, 10);

    const dist = Math.abs(c1 - c2) + Math.abs(r1 - r2);

    const clue = document.createElement('div');
    clue.className = 'clue-distance';

    if (dist <= 1) {
      clue.classList.add('dist-1');
      clue.innerHTML = `<span>1</span><span class="clue-sub">HOT!</span>`;
      elDrillHintBubble.textContent = 'ADJACENT (1)';
    } else if (dist === 2) {
      clue.classList.add('dist-2');
      clue.innerHTML = `<span>2</span><span class="clue-sub">WARM</span>`;
      elDrillHintBubble.textContent = 'WARM (2)';
    } else {
      clue.classList.add('dist-3');
      clue.innerHTML = `<span>${Math.min(dist, 4)}</span><span class="clue-sub">COOL</span>`;
      elDrillHintBubble.textContent = `DIST: ${dist}`;
    }

    cell.undergroundEl.appendChild(clue);
  }

  // --- ARROW CLUES (LEVEL 3) ---
  function renderArrowClue(cell) {
    const targetCell = findNearestTargetCell(cell);
    if (!targetCell) return;

    const c1 = parseInt(cell.dataset.col, 10);
    const r1 = parseInt(cell.dataset.row, 10);
    const c2 = parseInt(targetCell.dataset.col, 10);
    const r2 = parseInt(targetCell.dataset.row, 10);

    const dx = c2 - c1;
    const dy = r2 - r1;

    let arrowChar = '•';
    if (dx > 0 && dy === 0) arrowChar = '→';
    else if (dx < 0 && dy === 0) arrowChar = '←';
    else if (dx === 0 && dy > 0) arrowChar = '↓';
    else if (dx === 0 && dy < 0) arrowChar = '↑';
    else if (dx > 0 && dy > 0) arrowChar = '↘';
    else if (dx < 0 && dy > 0) arrowChar = '↙';
    else if (dx > 0 && dy < 0) arrowChar = '↗';
    else if (dx < 0 && dy < 0) arrowChar = '↖';

    const arrow = document.createElement('div');
    arrow.className = 'clue-arrow';
    arrow.textContent = arrowChar;

    cell.undergroundEl.appendChild(arrow);
    elDrillHintBubble.textContent = `FOLLOW ${arrowChar}`;
  }

  function findNearestTargetCell(fromCell) {
    const allCells = Array.from(elDigGrid.querySelectorAll('.grid-cell'));
    const c1 = parseInt(fromCell.dataset.col, 10);
    const r1 = parseInt(fromCell.dataset.row, 10);

    let nearest = null;
    let minDist = 999;

    allCells.forEach(cell => {
      const it = cell.itemData;
      if (!it) return;

      // In Level 4, point to key first, then to vault!
      let isCandidate = false;
      if (currentLevelIndex === 3) {
        if (!levelState.hasKey && it.isKey) isCandidate = true;
        if (levelState.hasKey && it.isVault) isCandidate = true;
      } else if (currentLevelIndex === 4) {
        if (!levelState.masterUnlocked && it.type === 'power_node' && !it.activated) isCandidate = true;
        if (levelState.masterUnlocked && it.isMaster) isCandidate = true;
      } else {
        if (it.isTarget && !it.collected) isCandidate = true;
      }

      if (isCandidate) {
        const c2 = parseInt(cell.dataset.col, 10);
        const r2 = parseInt(cell.dataset.row, 10);
        const d = Math.abs(c1 - c2) + Math.abs(r1 - r2);
        if (d < minDist) {
          minDist = d;
          nearest = cell;
        }
      }
    });

    return nearest;
  }

  // --- ITEM INTERACTIONS ---

  // Click on a Data Core
  function handleCoreClick(item, coreEl, cell) {
    if (item.collected) return;

    // Decoy core
    if (!item.isTarget && !item.isMaster) {
      showToast(`DECOY CORE ${item.value} (NOT THE TARGET)`);
      score += 20;
      updateScoreHUD();
      spawnParticles(coreEl, 6, '#7f91a4');
      return;
    }

    // Master Core locked check
    if (item.isMaster && item.locked) {
      showToast('SHIELD ACTIVE! ACTIVATE ALL 3 POWER NODES FIRST');
      spawnParticles(coreEl, 6, '#ff2a5f');
      return;
    }

    // LEVEL 1: Single Target
    if (currentLevelIndex === 0) {
      item.collected = true;
      spawnParticles(coreEl, 12, '#00f59b');
      showFloatingScore(cell, '+300 CORE 42');
      score += 300;
      updateScoreHUD();
      elPuzzleStatus.textContent = 'SOLVED!';
      elPuzzleStatus.style.color = '#00f59b';
      setTimeout(() => showLevelSuccess(LEVELS[0], 300), 500);
      return;
    }

    // LEVEL 2: Twin Match
    if (currentLevelIndex === 1) {
      item.collected = true;
      coreEl.style.opacity = '0.5';
      levelState.matched++;
      elHintText.textContent = `Dig up the 2 matching gold cores (${levelState.matched} of 2 found)`;
      spawnParticles(coreEl, 10, '#ffb703');
      showFloatingScore(cell, '+200 MATCH');
      score += 200;
      updateScoreHUD();

      if (levelState.matched >= levelState.required) {
        elPuzzleStatus.textContent = 'TWINS MATCHED!';
        elPuzzleStatus.style.color = '#00f59b';
        setTimeout(() => showLevelSuccess(LEVELS[1], 400), 500);
      } else {
        showToast('1 TWIN FOUND! LOCATE THE SECOND CORE [77]');
      }
      return;
    }

    // LEVEL 3: Arrow Target
    if (currentLevelIndex === 2) {
      item.collected = true;
      spawnParticles(coreEl, 14, '#00f59b');
      showFloatingScore(cell, '+500 CORE 99');
      score += 500;
      updateScoreHUD();
      elPuzzleStatus.textContent = 'SOLVED!';
      elPuzzleStatus.style.color = '#00f59b';
      setTimeout(() => showLevelSuccess(LEVELS[2], 500), 500);
      return;
    }

    // LEVEL 5: Master Core Extracted!
    if (currentLevelIndex === 4 && item.isMaster) {
      item.collected = true;
      spawnParticles(coreEl, 20, '#ffd700');
      showFloatingScore(cell, '+1000 MASTER Ω');
      score += 1000;
      updateScoreHUD();
      elPuzzleStatus.textContent = 'MASTER UNLOCKED!';
      elPuzzleStatus.style.color = '#ffd700';
      setTimeout(() => showVictory(), 600);
    }
  }

  // Level 4: Key Click
  function handleKeyClick(keyEl, cell) {
    if (levelState.hasKey) return;
    levelState.hasKey = true;
    keyEl.style.opacity = '0.4';
    spawnParticles(keyEl, 12, '#ffb703');
    showFloatingScore(cell, '+200 KEY');
    score += 200;
    updateScoreHUD();

    showToast('KEY ACQUIRED! NOW LOCATE AND UNLOCK THE VAULT');
    elHintText.textContent = 'Step 2: Key found! Dig up the Vault [🔒] to unlock it!';
    elDrillHintBubble.textContent = 'KEY IN HAND';

    // Unlock visual on vault if already exposed
    const vaultCell = Array.from(elDigGrid.querySelectorAll('.grid-cell')).find(c => c.itemData && c.itemData.isVault);
    if (vaultCell && vaultCell.vaultElement) {
      vaultCell.vaultElement.querySelector('.vault-icon').textContent = '🔓';
      vaultCell.vaultElement.querySelector('.item-label').textContent = 'READY TO UNLOCK';
    }
  }

  // Level 4: Vault Click
  function handleVaultClick(vaultEl, cell) {
    if (!levelState.hasKey) {
      showToast('VAULT LOCKED! FIND THE GOLDEN KEY [🔑] FIRST');
      spawnParticles(vaultEl, 6, '#ff2a5f');
      return;
    }

    levelState.vaultOpened = true;
    vaultEl.querySelector('.vault-icon').textContent = '✨';
    vaultEl.querySelector('.item-label').textContent = 'UNLOCKED!';
    spawnParticles(vaultEl, 16, '#00f59b');
    showFloatingScore(cell, '+600 VAULT');
    score += 600;
    updateScoreHUD();

    elPuzzleStatus.textContent = 'VAULT OPENED!';
    elPuzzleStatus.style.color = '#00f59b';
    setTimeout(() => showLevelSuccess(LEVELS[3], 600), 500);
  }

  // Level 5: Power Node Click
  function handlePowerNodeClick(nodeEl, item, cell) {
    if (item.activated) return;
    item.activated = true;
    levelState.nodesActive++;

    nodeEl.style.opacity = '0.5';
    spawnParticles(nodeEl, 10, '#00f59b');
    showFloatingScore(cell, '+150 NODE');
    score += 150;
    updateScoreHUD();

    elHintText.textContent = `Nodes active: ${levelState.nodesActive} / ${levelState.requiredNodes}`;

    if (levelState.nodesActive >= levelState.requiredNodes) {
      levelState.masterUnlocked = true;
      showToast('ALL 3 NODES ACTIVE! MASTER CORE Ω SHIELD DOWN!');
      elHintText.textContent = 'SHIELD DOWN! Click Master Core Ω to extract!';
      elPuzzleStatus.textContent = 'SHIELD DOWN';
      elPuzzleStatus.style.color = '#ffd700';

      const masterCell = Array.from(elDigGrid.querySelectorAll('.grid-cell')).find(c => c.itemData && c.itemData.isMaster);
      if (masterCell && masterCell.itemData) {
        masterCell.itemData.locked = false;
        spawnParticles(masterCell, 16, '#ffd700');
      }
    } else {
      showToast(`NODE 0${item.id} CHARGED! (${levelState.nodesActive}/3)`);
    }
  }

  // --- LEVEL SUCCESS ---
  function showLevelSuccess(level, bonus) {
    elLvlTitle.textContent = `STRATUM ${level.levelNum} CLEARED!`;
    elLvlDesc.textContent = `Puzzle objective achieved. Ready to drill deeper.`;
    elLvlDepthReached.textContent = `${level.depth}m`;
    elLvlBonusScore.textContent = `+${bonus}`;
    elOverlayLevel.classList.add('active');

    dispatchScoreUpdate('LEVEL_CLEARED', { level: level.levelNum });
  }

  function handleNextLevel() {
    elOverlayLevel.classList.remove('active');
    elStrataContainer.classList.add('layer-exit');

    setTimeout(() => {
      currentLevelIndex++;
      loadLevel(currentLevelIndex);

      elStrataContainer.classList.remove('layer-exit');
      elStrataContainer.classList.add('layer-enter');

      setTimeout(() => {
        elStrataContainer.classList.remove('layer-enter');
      }, 300);
    }, 350);
  }

  // --- VICTORY ---
  function showVictory() {
    const elapsed = Math.floor((Date.now() - (startTime || Date.now())) / 1000);
    const mins = Math.floor(elapsed / 60).toString().padStart(2, '0');
    const secs = (elapsed % 60).toString().padStart(2, '0');

    elVFinalScore.textContent = score.toLocaleString();
    elVFinalDepth.textContent = '200m';
    elVTeamId.textContent = teamId;
    elVTimeTaken.textContent = `${mins}:${secs}`;

    elOverlayVictory.classList.add('active');

    dispatchScoreUpdate('GAME_COMPLETE', {
      finalScore: score,
      finalDepth: 200,
      timeFormatted: `${mins}:${secs}`
    });
  }

  function handleRestart() {
    elOverlayVictory.classList.remove('active');
    handleStartGame();
  }

  // --- DRILL ANIMATION ---
  function animateDrillTo(targetEl) {
    positionDrillOver(targetEl);
    elDrillRig.classList.add('drilling');

    setTimeout(() => {
      elDrillRig.classList.remove('drilling');
    }, 240);
  }

  function positionDrillOver(element) {
    if (!element) {
      elDrillRig.style.left = '50%';
      elDrillRig.style.top = '10px';
      return;
    }

    const vpRect = elViewport.getBoundingClientRect();
    const elemRect = element.getBoundingClientRect();

    const targetX = elemRect.left + elemRect.width / 2 - vpRect.left;
    const targetY = elemRect.top - vpRect.top - 44;

    elDrillRig.style.left = `${Math.max(20, Math.min(vpRect.width - 20, targetX))}px`;
    elDrillRig.style.top = `${Math.max(10, targetY)}px`;
  }

  // --- PARTICLES & FLOATING TEXT ---
  function spawnParticles(targetEl, count, color) {
    if (activeParticles >= MAX_PARTICLES) return;

    const vpRect = elViewport.getBoundingClientRect();
    const tRect = targetEl.getBoundingClientRect();
    const startX = tRect.left + tRect.width / 2 - vpRect.left;
    const startY = tRect.top + tRect.height / 2 - vpRect.top;

    const allowed = Math.min(count, MAX_PARTICLES - activeParticles);

    for (let i = 0; i < allowed; i++) {
      activeParticles++;
      const p = document.createElement('div');
      p.className = 'excavate-particle';
      p.style.backgroundColor = color || '#00e5ff';
      p.style.left = `${startX}px`;
      p.style.top = `${startY}px`;

      const angle = Math.random() * Math.PI * 2;
      const dist = 12 + Math.random() * 28;
      const dx = Math.cos(angle) * dist;
      const dy = Math.sin(angle) * dist - 6;

      p.style.setProperty('--dx', `${dx}px`);
      p.style.setProperty('--dy', `${dy}px`);

      elParticlesLayer.appendChild(p);

      setTimeout(() => {
        if (p.parentNode) p.parentNode.removeChild(p);
        activeParticles = Math.max(0, activeParticles - 1);
      }, 400);
    }
  }

  function showFloatingScore(cell, text) {
    const vpRect = elViewport.getBoundingClientRect();
    const cRect = cell.getBoundingClientRect();

    const popup = document.createElement('div');
    popup.className = 'score-popup';
    popup.textContent = text;
    popup.style.left = `${cRect.left + cRect.width / 2 - vpRect.left}px`;
    popup.style.top = `${cRect.top - vpRect.top}px`;

    elParticlesLayer.appendChild(popup);
    setTimeout(() => {
      if (popup.parentNode) popup.parentNode.removeChild(popup);
    }, 750);
  }

  function getStrataColor() {
    switch (currentLevelIndex) {
      case 0: return '#6b543b';
      case 1: return '#446282';
      case 2: return '#86559c';
      case 3: return '#00e5ff';
      case 4: return '#ffb703';
      default: return '#00e5ff';
    }
  }

  function updateScoreHUD() {
    elScore.textContent = score.toLocaleString();
  }

  function showToast(msg) {
    elToast.textContent = msg;
    elToast.classList.add('active');
    clearTimeout(elToast._timer);
    elToast._timer = setTimeout(() => {
      elToast.classList.remove('active');
    }, 1800);
  }

  function shuffle(arr) {
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  }

  function dispatchScoreUpdate(action, extra = {}) {
    const payload = {
      type: 'DIG_THE_DATA_EVENT',
      action: action,
      game: 'game1',
      teamId: teamId,
      score: score,
      depth: currentDepth,
      level: currentLevelIndex + 1,
      timestamp: Date.now(),
      ...extra,
    };

    try {
      if (window.parent && window.parent !== window) {
        window.parent.postMessage(payload, '*');
      }
    } catch (e) {}

    window.dispatchEvent(new CustomEvent('dig-the-data-score', { detail: payload }));
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
