/**
 * QUICK MINI CROSSWORD - GAME ENGINE
 * Simple, fast, and satisfying 3x3 mini crossword puzzles with instant auto-validation,
 * letter bank tiles, 1-tap hints, confetti victory celebration, and persistent progress.
 */

(function() {
  'use strict';

  // --- 7 QUICK MINI PUZZLES (ALL 3x3 WITH EVERYDAY VOCABULARY) ---
  const MINI_PUZZLES = [
    {
      id: 'mini_1',
      title: 'Pets & Play',
      grid: [
        ['C', 'A', 'T'],
        ['U', '#', 'O'],
        ['P', 'O', 'P']
      ],
      clues: {
        across: {
          1: 'Feline pet that purrs and meows',
          3: 'Burst a balloon with a loud snap'
        },
        down: {
          1: 'Mug used for warm coffee or tea',
          2: 'Spinning toy or highest summit'
        }
      }
    },
    {
      id: 'mini_2',
      title: 'Sun & Soup',
      grid: [
        ['S', 'U', 'N'],
        ['I', '#', 'E'],
        ['P', 'O', 'T']
      ],
      clues: {
        across: {
          1: 'Bright star in the daytime sky',
          3: 'Deep pan used for boiling soup'
        },
        down: {
          1: 'Drink a tiny taste of juice',
          2: 'Mesh basket used in fishing or hoops'
        }
      }
    },
    {
      id: 'mini_3',
      title: 'Farm & Sprint',
      grid: [
        ['C', 'O', 'W'],
        ['A', '#', 'I'],
        ['R', 'U', 'N']
      ],
      clues: {
        across: {
          1: 'Barn animal that gives milk and moos',
          3: 'Sprint or jog with your legs'
        },
        down: {
          1: 'Motor vehicle with four wheels',
          2: 'Finish in 1st place in a contest'
        }
      }
    },
    {
      id: 'mini_4',
      title: 'Red Dog',
      grid: [
        ['R', 'I', 'P'],
        ['E', '#', 'I'],
        ['D', 'O', 'G']
      ],
      clues: {
        across: {
          1: 'Tear a piece of paper',
          3: 'Man\'s best friend that barks'
        },
        down: {
          1: 'Color of a ripe apple or strawberry',
          2: 'Pink farm animal with a curly tail'
        }
      }
    },
    {
      id: 'mini_5',
      title: 'Pure Elements',
      grid: [
        ['A', 'I', 'R'],
        ['I', 'C', 'E'],
        ['R', 'E', 'D']
      ],
      clues: {
        across: {
          1: 'What we breathe to stay alive',
          4: 'Frozen cold water cube',
          5: 'Color of a bright stop sign'
        },
        down: {
          1: 'What fills a balloon or our lungs',
          2: 'Chilled ice cubes in a drink',
          3: 'Warm primary color like ruby'
        }
      }
    },
    {
      id: 'mini_6',
      title: 'Tea Time',
      grid: [
        ['N', 'E', 'T'],
        ['E', 'Y', 'E'],
        ['T', 'E', 'A']
      ],
      clues: {
        across: {
          1: 'Tennis court divider or soccer goal',
          4: 'Facial organ used for seeing',
          5: 'Warm steeped herbal drink in a cup'
        },
        down: {
          1: 'Spider web or badminton mesh',
          2: 'Organ of vision with an iris',
          3: 'Soothing hot brew like Earl Grey'
        }
      }
    },
    {
      id: 'mini_7',
      title: 'Ink & Vision',
      grid: [
        ['P', 'E', 'N'],
        ['E', 'Y', 'E'],
        ['N', 'E', 'T']
      ],
      clues: {
        across: {
          1: 'Writing tool filled with ink',
          4: 'Body part used to blink and look',
          5: 'Mesh fabric used to catch fish'
        },
        down: {
          1: 'Ballpoint writing instrument',
          2: 'Sense of sight organ',
          3: 'Goal net in hockey or soccer'
        }
      }
    }
  ];

  // --- AUDIO SYNTHESIS ---
  let audioCtx = null;
  let isMuted = localStorage.getItem('mini_cw_muted') === 'true';

  function initAudio() {
    if (!audioCtx) {
      const AudioClass = window.AudioContext || window.webkitAudioContext;
      if (AudioClass) audioCtx = new AudioClass();
    }
    if (audioCtx && audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
  }

  function playTone(freq, type = 'sine', duration = 0.08, gainVal = 0.12) {
    if (isMuted || !audioCtx) return;
    try {
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
      gain.gain.setValueAtTime(gainVal, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + duration);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + duration);
    } catch (e) {}
  }

  function soundTick() {
    initAudio();
    playTone(587.33, 'sine', 0.04, 0.08); // D5
  }

  function soundSolved() {
    initAudio();
    if (isMuted || !audioCtx) return;
    [523.25, 659.25, 783.99].forEach((f, idx) => {
      setTimeout(() => playTone(f, 'triangle', 0.12, 0.1), idx * 70);
    });
  }

  function soundVictory() {
    initAudio();
    if (isMuted || !audioCtx) return;
    [523.25, 659.25, 783.99, 1046.50].forEach((f, idx) => {
      setTimeout(() => playTone(f, 'sine', 0.22, 0.12), idx * 85);
    });
  }

  // --- PERSISTENCE FOR SOLVED PUZZLES ---
  let solvedPuzzleIds = new Set();
  try {
    const saved = JSON.parse(localStorage.getItem('mini_cw_solved_ids') || '[]');
    if (Array.isArray(saved)) solvedPuzzleIds = new Set(saved);
  } catch (e) {}

  function markPuzzleSolved(id) {
    solvedPuzzleIds.add(id);
    try {
      localStorage.setItem('mini_cw_solved_ids', JSON.stringify([...solvedPuzzleIds]));
    } catch (e) {}
    updateSelectDropdown();
  }

  // --- STATE ---
  const MAX_HINTS = 3;
  let hintsRemaining = MAX_HINTS;
  let activeIndex = 0;
  let activePuzzle = null;
  let solutionGrid = [];
  let userGrid = [];
  let cellNumbers = [];
  let acrossClues = [];
  let downClues = [];

  let selectedRow = 0;
  let selectedCol = 0;
  let selectedDir = 'across'; // 'across' | 'down'

  let timerSeconds = 0;
  let timerInterval = null;
  let score = 0;
  let isSolved = false;
  let teamId = localStorage.getItem('dig_the_data_team_id') || 'TEAM_ALPHA';

  const urlParams = new URLSearchParams(window.location.search);
  if (urlParams.get('teamId')) teamId = urlParams.get('teamId');

  // --- DOM REFERENCES ---
  const elSelect = document.getElementById('puzzle-select');
  const elTimer = document.getElementById('cw-timer');
  const elProgress = document.getElementById('cw-words-progress');
  const elScore = document.getElementById('cw-score');
  const elGrid = document.getElementById('crossword-grid');
  const elLetterBank = document.getElementById('letter-bank');
  const elBtnShuffle = document.getElementById('btn-shuffle-bank');

  const elClueNum = document.getElementById('active-clue-number');
  const elClueText = document.getElementById('active-clue-text');
  const elClueLen = document.getElementById('active-clue-len');
  const elDirName = document.getElementById('dir-name');

  const elAcrossList = document.getElementById('across-clues-list');
  const elDownList = document.getElementById('down-clues-list');

  const elBtnHint = document.getElementById('btn-hint');
  const elHintBadge = document.getElementById('hint-badge');
  const elBtnSound = document.getElementById('btn-sound-toggle');
  const elSoundIcon = document.getElementById('sound-icon');
  const elBtnReset = document.getElementById('btn-reset-puzzle');
  const elBtnPrev = document.getElementById('btn-prev-clue');
  const elBtnNext = document.getElementById('btn-next-clue');
  const elBtnDel = document.getElementById('btn-del-letter');
  const elBtnSwitchDir = document.getElementById('btn-switch-dir');
  const elBtnClear = document.getElementById('btn-clear-all');

  const elVictory = document.getElementById('modal-victory');
  const elVPuzzleName = document.getElementById('v-puzzle-name');
  const elVTime = document.getElementById('v-time');
  const elVScore = document.getElementById('v-score');
  const elBtnNextPuzzle = document.getElementById('btn-next-puzzle');
  const elConfettiCanvas = document.getElementById('confetti-canvas');
  const elToast = document.getElementById('mini-toast');

  let toastTimer = null;
  function showToast(msg) {
    if (toastTimer) clearTimeout(toastTimer);
    elToast.textContent = msg;
    elToast.classList.add('toast-show');
    toastTimer = setTimeout(() => elToast.classList.remove('toast-show'), 1800);
  }

  // --- CONFETTI SYSTEM ---
  let confettiAnimId = null;
  let confettiParticles = [];

  function startConfetti() {
    if (!elConfettiCanvas) return;
    const ctx = elConfettiCanvas.getContext('2d');
    if (!ctx) return;

    elConfettiCanvas.width = window.innerWidth;
    elConfettiCanvas.height = window.innerHeight;

    const colors = ['#38bdf8', '#22c55e', '#f59e0b', '#ec4899', '#a855f7', '#ffffff'];
    confettiParticles = [];

    for (let i = 0; i < 70; i++) {
      confettiParticles.push({
        x: Math.random() * elConfettiCanvas.width,
        y: Math.random() * (elConfettiCanvas.height * 0.3),
        vx: (Math.random() - 0.5) * 6,
        vy: Math.random() * 4 + 2,
        size: Math.random() * 8 + 6,
        color: colors[Math.floor(Math.random() * colors.length)],
        rotation: Math.random() * 360,
        rotSpeed: (Math.random() - 0.5) * 8
      });
    }

    function loop() {
      ctx.clearRect(0, 0, elConfettiCanvas.width, elConfettiCanvas.height);
      confettiParticles.forEach(p => {
        p.x += p.vx;
        p.y += p.vy;
        p.rotation += p.rotSpeed;

        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate((p.rotation * Math.PI) / 180);
        ctx.fillStyle = p.color;
        ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size * 0.6);
        ctx.restore();

        if (p.y > elConfettiCanvas.height) {
          p.y = -10;
          p.x = Math.random() * elConfettiCanvas.width;
        }
      });

      confettiAnimId = requestAnimationFrame(loop);
    }

    if (confettiAnimId) cancelAnimationFrame(confettiAnimId);
    loop();
  }

  function stopConfetti() {
    if (confettiAnimId) {
      cancelAnimationFrame(confettiAnimId);
      confettiAnimId = null;
    }
    if (elConfettiCanvas) {
      const ctx = elConfettiCanvas.getContext('2d');
      if (ctx) ctx.clearRect(0, 0, elConfettiCanvas.width, elConfettiCanvas.height);
    }
  }

  // --- PARSE GRID ---
  function parseGrid(puzzle) {
    const raw = puzzle.grid;
    const R = raw.length;
    const C = raw[0].length;
    let num = 1;
    const numbers = Array.from({ length: R }, () => Array(C).fill(0));
    const across = [];
    const down = [];

    for (let r = 0; r < R; r++) {
      for (let c = 0; c < C; c++) {
        if (raw[r][c] === '#') continue;
        const startsA = (c === 0 || raw[r][c - 1] === '#') && (c + 1 < C && raw[r][c + 1] !== '#');
        const startsD = (r === 0 || raw[r - 1][c] === '#') && (r + 1 < R && raw[r + 1][c] !== '#');

        if (startsA || startsD) {
          numbers[r][c] = num;
          if (startsA) {
            let w = '';
            let cc = c;
            const cells = [];
            while (cc < C && raw[r][cc] !== '#') {
              w += raw[r][cc];
              cells.push({ r, c: cc });
              cc++;
            }
            across.push({
              num,
              r,
              c,
              len: w.length,
              word: w,
              clue: puzzle.clues.across[num] || 'Clue',
              cells
            });
          }
          if (startsD) {
            let w = '';
            let rr = r;
            const cells = [];
            while (rr < R && raw[rr][c] !== '#') {
              w += raw[rr][c];
              cells.push({ r: rr, c });
              rr++;
            }
            down.push({
              num,
              r,
              c,
              len: w.length,
              word: w,
              clue: puzzle.clues.down[num] || 'Clue',
              cells
            });
          }
          num++;
        }
      }
    }
    return { numbers, across, down, R, C };
  }

  // --- TELEMETRY ---
  function sendTelemetry(action) {
    const totalWords = acrossClues.length + downClues.length;
    const solvedWords = countSolvedWords();
    const payload = {
      type: 'CROSSWORD_EVENT',
      action: action,
      score: score,
      depth: solvedWords,
      level: activeIndex + 1,
      teamId: teamId,
      puzzleTitle: activePuzzle.title,
      timeSeconds: timerSeconds,
      wordsSolved: solvedWords,
      totalWords: totalWords,
      hintsRemaining: hintsRemaining
    };
    window.parent.postMessage(payload, '*');
    window.parent.postMessage({
      type: 'DIG_THE_DATA_EVENT',
      action: action,
      score: score,
      depth: solvedWords,
      level: activeIndex + 1,
      teamId: teamId
    }, '*');
  }

  // --- LOAD PUZZLE ---
  function loadPuzzle(idx) {
    stopConfetti();
    activeIndex = idx;
    activePuzzle = MINI_PUZZLES[idx];
    solutionGrid = activePuzzle.grid;

    const parsed = parseGrid(activePuzzle);
    cellNumbers = parsed.numbers;
    acrossClues = parsed.across;
    downClues = parsed.down;

    userGrid = Array.from({ length: 3 }, () => Array(3).fill(''));
    isSolved = false;
    timerSeconds = 0;
    hintsRemaining = MAX_HINTS;
    updateHintButtonUI();
    clearInterval(timerInterval);
    timerInterval = setInterval(() => {
      if (isSolved) return;
      timerSeconds++;
      const m = String(Math.floor(timerSeconds / 60)).padStart(2, '0');
      const s = String(timerSeconds % 60).padStart(2, '0');
      elTimer.textContent = `${m}:${s}`;
    }, 1000);

    selectedRow = acrossClues[0]?.r ?? 0;
    selectedCol = acrossClues[0]?.c ?? 0;
    selectedDir = 'across';

    renderGrid();
    renderLetterBank();
    renderClues();
    updateActiveClue();
    updateProgress();
    elDirName.textContent = selectedDir.toUpperCase();

    sendTelemetry('PUZZLE_LOADED');
  }

  // --- RENDER GRID ---
  function renderGrid() {
    elGrid.innerHTML = '';
    for (let r = 0; r < 3; r++) {
      for (let c = 0; c < 3; c++) {
        const cell = document.createElement('div');
        cell.className = 'cw-cell';
        cell.id = `cell-${r}-${c}`;

        if (solutionGrid[r][c] === '#') {
          cell.classList.add('cell-block');
        } else {
          const num = cellNumbers[r][c];
          if (num > 0) {
            const numSpan = document.createElement('span');
            numSpan.className = 'cell-number';
            numSpan.textContent = num;
            cell.appendChild(numSpan);
          }
          const letterSpan = document.createElement('span');
          letterSpan.className = 'cell-letter';
          letterSpan.id = `txt-${r}-${c}`;
          letterSpan.textContent = userGrid[r][c] || '';
          cell.appendChild(letterSpan);

          cell.addEventListener('click', () => handleCellClick(r, c));
        }
        elGrid.appendChild(cell);
      }
    }
    updateCellHighlights();
  }

  // --- RENDER LETTER BANK TILES ---
  function renderLetterBank() {
    elLetterBank.innerHTML = '';
    const letters = [];
    for (let r = 0; r < 3; r++) {
      for (let c = 0; c < 3; c++) {
        if (solutionGrid[r][c] !== '#') {
          letters.push(solutionGrid[r][c]);
        }
      }
    }
    // Shuffle
    letters.sort(() => Math.random() - 0.5);

    letters.forEach(char => {
      const btn = document.createElement('button');
      btn.className = 'letter-tile-btn';
      btn.textContent = char;
      btn.addEventListener('click', () => {
        enterLetter(char);
      });
      elLetterBank.appendChild(btn);
    });
  }

  // --- RENDER CLUES ---
  function renderClues() {
    elAcrossList.innerHTML = '';
    elDownList.innerHTML = '';

    acrossClues.forEach(c => {
      const card = document.createElement('div');
      card.className = 'clue-card';
      card.id = `card-across-${c.num}`;
      card.innerHTML = `
        <span class="clue-card-num">${c.num}</span>
        <span class="clue-card-text">${c.clue}</span>
        <span class="clue-card-check" id="chk-across-${c.num}"></span>
      `;
      card.addEventListener('click', () => {
        selectedDir = 'across';
        elDirName.textContent = 'ACROSS';
        // Pick first empty cell or start of word
        const emptyCell = c.cells.find(p => userGrid[p.r][p.c] === '');
        selectedRow = emptyCell ? emptyCell.r : c.r;
        selectedCol = emptyCell ? emptyCell.c : c.c;
        updateCellHighlights();
        updateActiveClue();
      });
      elAcrossList.appendChild(card);
    });

    downClues.forEach(c => {
      const card = document.createElement('div');
      card.className = 'clue-card';
      card.id = `card-down-${c.num}`;
      card.innerHTML = `
        <span class="clue-card-num">${c.num}</span>
        <span class="clue-card-text">${c.clue}</span>
        <span class="clue-card-check" id="chk-down-${c.num}"></span>
      `;
      card.addEventListener('click', () => {
        selectedDir = 'down';
        elDirName.textContent = 'DOWN';
        // Pick first empty cell or start of word
        const emptyCell = c.cells.find(p => userGrid[p.r][p.c] === '');
        selectedRow = emptyCell ? emptyCell.r : c.r;
        selectedCol = emptyCell ? emptyCell.c : c.c;
        updateCellHighlights();
        updateActiveClue();
      });
      elDownList.appendChild(card);
    });
  }

  // --- ACTIVE CLUE / SELECTION ---
  function getActiveClue() {
    const list = selectedDir === 'across' ? acrossClues : downClues;
    return list.find(c => c.cells.some(p => p.r === selectedRow && p.c === selectedCol)) || list[0];
  }

  function updateActiveClue() {
    const clue = getActiveClue();
    if (!clue) return;

    elClueNum.textContent = `${clue.num} ${selectedDir.toUpperCase()}`;
    elClueText.textContent = clue.clue;
    elClueLen.textContent = `(${clue.len} letters)`;

    document.querySelectorAll('.clue-card').forEach(el => el.classList.remove('card-active'));
    const activeCard = document.getElementById(`card-${selectedDir}-${clue.num}`);
    if (activeCard) activeCard.classList.add('card-active');
  }

  function updateCellHighlights() {
    document.querySelectorAll('.cw-cell').forEach(c => {
      c.classList.remove('cell-active', 'cell-in-word');
    });

    const activeClue = getActiveClue();
    if (activeClue) {
      activeClue.cells.forEach(p => {
        const el = document.getElementById(`cell-${p.r}-${p.c}`);
        if (el) el.classList.add('cell-in-word');
      });
    }

    const cur = document.getElementById(`cell-${selectedRow}-${selectedCol}`);
    if (cur) cur.classList.add('cell-active');
  }

  function handleCellClick(r, c) {
    initAudio();
    if (solutionGrid[r][c] === '#') return;

    if (selectedRow === r && selectedCol === c) {
      toggleDirection();
    } else {
      selectedRow = r;
      selectedCol = c;
      const curClue = getActiveClue();
      const inCurrent = curClue?.cells.some(p => p.r === r && p.c === c);
      if (!inCurrent) {
        const otherDir = selectedDir === 'across' ? 'down' : 'across';
        const otherList = otherDir === 'across' ? acrossClues : downClues;
        if (otherList.some(c => c.cells.some(p => p.r === r && p.c === c))) {
          selectedDir = otherDir;
          elDirName.textContent = selectedDir.toUpperCase();
        }
      }
    }
    updateCellHighlights();
    updateActiveClue();
  }

  function toggleDirection() {
    const nextDir = selectedDir === 'across' ? 'down' : 'across';
    const nextList = nextDir === 'across' ? acrossClues : downClues;
    if (nextList.some(c => c.cells.some(p => p.r === selectedRow && p.c === selectedCol))) {
      selectedDir = nextDir;
      elDirName.textContent = selectedDir.toUpperCase();
      updateCellHighlights();
      updateActiveClue();
    }
  }

  // --- LETTER ENTRY & VALIDATION ---
  function enterLetter(char) {
    if (isSolved) return;
    if (solutionGrid[selectedRow][selectedCol] === '#') return;

    userGrid[selectedRow][selectedCol] = char.toUpperCase();
    const txtEl = document.getElementById(`txt-${selectedRow}-${selectedCol}`);
    if (txtEl) txtEl.textContent = char.toUpperCase();

    soundTick();

    advanceInWord();
    checkWordsSolved();
    checkVictory();
  }

  function advanceInWord() {
    const clue = getActiveClue();
    if (!clue) return;

    const idx = clue.cells.findIndex(p => p.r === selectedRow && p.c === selectedCol);
    if (idx !== -1 && idx < clue.cells.length - 1) {
      selectedRow = clue.cells[idx + 1].r;
      selectedCol = clue.cells[idx + 1].c;
      updateCellHighlights();
      updateActiveClue();
    }
  }

  function deleteLetter() {
    if (isSolved) return;
    if (solutionGrid[selectedRow][selectedCol] === '#') return;

    if (userGrid[selectedRow][selectedCol] !== '') {
      userGrid[selectedRow][selectedCol] = '';
      const txtEl = document.getElementById(`txt-${selectedRow}-${selectedCol}`);
      if (txtEl) txtEl.textContent = '';
      soundTick();
    } else {
      const clue = getActiveClue();
      if (clue) {
        const idx = clue.cells.findIndex(p => p.r === selectedRow && p.c === selectedCol);
        if (idx > 0) {
          selectedRow = clue.cells[idx - 1].r;
          selectedCol = clue.cells[idx - 1].c;
          userGrid[selectedRow][selectedCol] = '';
          const txtEl = document.getElementById(`txt-${selectedRow}-${selectedCol}`);
          if (txtEl) txtEl.textContent = '';
          soundTick();
          updateCellHighlights();
          updateActiveClue();
        }
      }
    }
    checkWordsSolved();
  }

  function isClueCorrect(c) {
    return c.cells.every(p => userGrid[p.r][p.c] === solutionGrid[p.r][p.c]);
  }

  function checkWordsSolved() {
    let newlySolved = false;

    acrossClues.forEach(c => {
      const card = document.getElementById(`card-across-${c.num}`);
      const chk = document.getElementById(`chk-across-${c.num}`);
      if (isClueCorrect(c)) {
        if (!card.classList.contains('card-solved')) {
          card.classList.add('card-solved');
          if (chk) chk.textContent = '✓';
          c.cells.forEach(p => {
            document.getElementById(`cell-${p.r}-${p.c}`)?.classList.add('cell-solved');
          });
          newlySolved = true;
          score += 100;
        }
      } else {
        if (card.classList.contains('card-solved')) {
          card.classList.remove('card-solved');
          if (chk) chk.textContent = '';
          score = Math.max(0, score - 100);
        }
      }
    });

    downClues.forEach(c => {
      const card = document.getElementById(`card-down-${c.num}`);
      const chk = document.getElementById(`chk-down-${c.num}`);
      if (isClueCorrect(c)) {
        if (!card.classList.contains('card-solved')) {
          card.classList.add('card-solved');
          if (chk) chk.textContent = '✓';
          c.cells.forEach(p => {
            document.getElementById(`cell-${p.r}-${p.c}`)?.classList.add('cell-solved');
          });
          newlySolved = true;
          score += 100;
        }
      } else {
        if (card.classList.contains('card-solved')) {
          card.classList.remove('card-solved');
          if (chk) chk.textContent = '';
          score = Math.max(0, score - 100);
        }
      }
    });

    if (newlySolved) {
      soundSolved();
    }

    elScore.textContent = score;
    updateProgress();
  }

  function countSolvedWords() {
    let count = 0;
    acrossClues.forEach(c => { if (isClueCorrect(c)) count++; });
    downClues.forEach(c => { if (isClueCorrect(c)) count++; });
    return count;
  }

  function updateProgress() {
    const total = acrossClues.length + downClues.length;
    const solved = countSolvedWords();
    elProgress.textContent = `${solved}/${total}`;
  }

  // --- VICTORY CHECK ---
  function checkVictory() {
    for (let r = 0; r < 3; r++) {
      for (let c = 0; c < 3; c++) {
        if (solutionGrid[r][c] === '#') continue;
        if (userGrid[r][c] !== solutionGrid[r][c]) {
          return;
        }
      }
    }

    if (!isSolved) {
      isSolved = true;
      clearInterval(timerInterval);

      // Fast completion bonus
      const bonus = Math.max(50, 300 - timerSeconds * 5);
      score += bonus;
      elScore.textContent = score;

      soundVictory();
      markPuzzleSolved(activePuzzle.id);

      elVPuzzleName.textContent = `You solved "${activePuzzle.title}" in ${timerSeconds}s!`;
      const m = String(Math.floor(timerSeconds / 60)).padStart(2, '0');
      const s = String(timerSeconds % 60).padStart(2, '0');
      elVTime.textContent = `${m}:${s}`;
      elVScore.textContent = score;

      elVictory.classList.add('active');
      startConfetti();

      sendTelemetry('PUZZLE_SOLVED');
    }
  }

  // --- HINT (MAX 3 PER PUZZLE) ---
  function updateHintButtonUI() {
    if (elHintBadge) {
      elHintBadge.textContent = hintsRemaining;
    }
    if (hintsRemaining <= 0) {
      elBtnHint.disabled = true;
      elBtnHint.classList.add('disabled');
      elBtnHint.title = 'No hints remaining (0/3 used)';
    } else {
      elBtnHint.disabled = false;
      elBtnHint.classList.remove('disabled');
      elBtnHint.title = `Get a quick hint (${hintsRemaining} of 3 remaining)`;
    }
  }

  function giveHint() {
    if (isSolved) return;

    if (hintsRemaining <= 0) {
      showToast('No hints remaining for this puzzle!');
      return;
    }

    let targetR = selectedRow;
    let targetC = selectedCol;

    if (solutionGrid[targetR][targetC] === '#' || userGrid[targetR][targetC] === solutionGrid[targetR][targetC]) {
      const clue = getActiveClue();
      const nextCell = clue?.cells.find(p => userGrid[p.r][p.c] !== solutionGrid[p.r][p.c]);
      if (nextCell) {
        targetR = nextCell.r;
        targetC = nextCell.c;
      } else {
        for (let r = 0; r < 3; r++) {
          for (let c = 0; c < 3; c++) {
            if (solutionGrid[r][c] !== '#' && userGrid[r][c] !== solutionGrid[r][c]) {
              targetR = r;
              targetC = c;
              break;
            }
          }
        }
      }
    }

    // If still matching or block, everything is already correct!
    if (solutionGrid[targetR][targetC] === '#' || userGrid[targetR][targetC] === solutionGrid[targetR][targetC]) {
      showToast('All visible letters are already correct!');
      return;
    }

    hintsRemaining--;
    updateHintButtonUI();

    selectedRow = targetR;
    selectedCol = targetC;
    const correctLetter = solutionGrid[targetR][targetC];
    userGrid[targetR][targetC] = correctLetter;

    const txtEl = document.getElementById(`txt-${targetR}-${targetC}`);
    if (txtEl) txtEl.textContent = correctLetter;

    const remainingMsg = hintsRemaining === 1 ? '1 hint left' : `${hintsRemaining} hints left`;
    showToast(`Hint: ${correctLetter} (${remainingMsg})`);
    soundTick();
    advanceInWord();
    checkWordsSolved();
    checkVictory();
    sendTelemetry('HINT_USED');
  }

  // --- CLEAR GRID ---
  function clearGrid() {
    for (let r = 0; r < 3; r++) {
      for (let c = 0; c < 3; c++) {
        userGrid[r][c] = '';
        const txtEl = document.getElementById(`txt-${r}-${c}`);
        if (txtEl) txtEl.textContent = '';
      }
    }
    document.querySelectorAll('.cw-cell').forEach(c => c.classList.remove('cell-solved'));
    document.querySelectorAll('.clue-card').forEach(c => c.classList.remove('card-solved'));
    document.querySelectorAll('.clue-card-check').forEach(c => c.textContent = '');
    score = 0;
    elScore.textContent = 0;
    updateProgress();
    showToast('Grid cleared');
  }

  // --- KEYBOARD LISTENER ---
  window.addEventListener('keydown', (e) => {
    if (elVictory.classList.contains('active')) {
      if (e.key === 'Enter') {
        elBtnNextPuzzle.click();
      }
      return;
    }

    const key = e.key;
    if (/^[a-zA-Z]$/.test(key)) {
      e.preventDefault();
      enterLetter(key);
    } else if (key === 'Backspace' || key === 'Delete') {
      e.preventDefault();
      deleteLetter();
    } else if (key === ' ' || key === 'Enter') {
      e.preventDefault();
      toggleDirection();
    } else if (key === 'Tab') {
      e.preventDefault();
      const all = [...acrossClues.map(c => ({ ...c, dir: 'across' })), ...downClues.map(c => ({ ...c, dir: 'down' }))];
      const curClue = getActiveClue();
      const curIdx = all.findIndex(c => c.dir === selectedDir && c.num === curClue.num);
      const nextClue = all[(curIdx + 1) % all.length];
      selectedDir = nextClue.dir;
      selectedRow = nextClue.r;
      selectedCol = nextClue.c;
      elDirName.textContent = selectedDir.toUpperCase();
      updateCellHighlights();
      updateActiveClue();
    } else if (key === 'ArrowRight') {
      e.preventDefault();
      if (selectedCol < 2 && solutionGrid[selectedRow][selectedCol + 1] !== '#') {
        selectedCol++;
        selectedDir = 'across';
        elDirName.textContent = 'ACROSS';
        updateCellHighlights();
        updateActiveClue();
      }
    } else if (key === 'ArrowLeft') {
      e.preventDefault();
      if (selectedCol > 0 && solutionGrid[selectedRow][selectedCol - 1] !== '#') {
        selectedCol--;
        selectedDir = 'across';
        elDirName.textContent = 'ACROSS';
        updateCellHighlights();
        updateActiveClue();
      }
    } else if (key === 'ArrowDown') {
      e.preventDefault();
      if (selectedRow < 2 && solutionGrid[selectedRow + 1][selectedCol] !== '#') {
        selectedRow++;
        selectedDir = 'down';
        elDirName.textContent = 'DOWN';
        updateCellHighlights();
        updateActiveClue();
      }
    } else if (key === 'ArrowUp') {
      e.preventDefault();
      if (selectedRow > 0 && solutionGrid[selectedRow - 1][selectedCol] !== '#') {
        selectedRow--;
        selectedDir = 'down';
        elDirName.textContent = 'DOWN';
        updateCellHighlights();
        updateActiveClue();
      }
    }
  });

  // --- BUTTON ACTIONS ---
  elBtnHint.addEventListener('click', giveHint);
  elBtnDel.addEventListener('click', deleteLetter);
  elBtnSwitchDir.addEventListener('click', toggleDirection);
  elBtnClear.addEventListener('click', clearGrid);

  if (elBtnShuffle) {
    elBtnShuffle.addEventListener('click', () => {
      renderLetterBank();
      showToast('Letters shuffled');
    });
  }

  elBtnSound.addEventListener('click', () => {
    initAudio();
    isMuted = !isMuted;
    localStorage.setItem('mini_cw_muted', isMuted ? 'true' : 'false');
    elSoundIcon.innerHTML = isMuted ? '&#128263;' : '&#128266;';
    showToast(isMuted ? 'Muted' : 'Sound On');
  });

  elBtnReset.addEventListener('click', () => {
    loadPuzzle(activeIndex);
    showToast('Puzzle restarted');
  });

  elBtnPrev.addEventListener('click', () => {
    const all = [...acrossClues.map(c => ({ ...c, dir: 'across' })), ...downClues.map(c => ({ ...c, dir: 'down' }))];
    const curClue = getActiveClue();
    const curIdx = all.findIndex(c => c.dir === selectedDir && c.num === curClue.num);
    const prevClue = all[(curIdx - 1 + all.length) % all.length];
    selectedDir = prevClue.dir;
    selectedRow = prevClue.r;
    selectedCol = prevClue.c;
    elDirName.textContent = selectedDir.toUpperCase();
    updateCellHighlights();
    updateActiveClue();
  });

  elBtnNext.addEventListener('click', () => {
    const all = [...acrossClues.map(c => ({ ...c, dir: 'across' })), ...downClues.map(c => ({ ...c, dir: 'down' }))];
    const curClue = getActiveClue();
    const curIdx = all.findIndex(c => c.dir === selectedDir && c.num === curClue.num);
    const nextClue = all[(curIdx + 1) % all.length];
    selectedDir = nextClue.dir;
    selectedRow = nextClue.r;
    selectedCol = nextClue.c;
    elDirName.textContent = selectedDir.toUpperCase();
    updateCellHighlights();
    updateActiveClue();
  });

  elBtnNextPuzzle.addEventListener('click', () => {
    stopConfetti();
    elVictory.classList.remove('active');
    const nextIdx = (activeIndex + 1) % MINI_PUZZLES.length;
    elSelect.value = nextIdx;
    loadPuzzle(nextIdx);
  });

  // Populate Select with solved indicators
  function updateSelectDropdown() {
    elSelect.innerHTML = '';
    MINI_PUZZLES.forEach((p, i) => {
      const opt = document.createElement('option');
      opt.value = i;
      const isDone = solvedPuzzleIds.has(p.id);
      opt.textContent = `${i + 1}. ${p.title}${isDone ? ' ✓' : ''}`;
      elSelect.appendChild(opt);
    });
    elSelect.value = activeIndex;
  }

  elSelect.addEventListener('change', (e) => {
    loadPuzzle(parseInt(e.target.value, 10));
  });

  // Launcher message sync
  window.addEventListener('message', (e) => {
    if (e.data?.type === 'SET_TEAM_ID' && e.data.teamId) {
      teamId = e.data.teamId;
      localStorage.setItem('dig_the_data_team_id', teamId);
    }
  });

  elSoundIcon.innerHTML = isMuted ? '&#128263;' : '&#128266;';

  // Initialize
  updateSelectDropdown();
  loadPuzzle(0);

  // Send ready event to launcher
  window.parent.postMessage({ type: 'GAME_READY', game: 'mini-crossword' }, '*');

})();
