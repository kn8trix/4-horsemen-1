/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { Terminal, ExternalLink, RotateCcw, Cpu, ChevronUp, ChevronDown, CheckCircle2 } from 'lucide-react';

interface GameEvent {
  time: string;
  type: string;
  action?: string;
  level?: number;
  depth?: number;
  score?: number;
  teamId?: string;
}

export default function App() {
  const [teamId, setTeamId] = useState<string>(() => {
    const params = new URLSearchParams(window.location.search);
    return params.get('teamId') || localStorage.getItem('dig_the_data_team_id') || 'TEAM_ALPHA';
  });
  const [isEditingTeam, setIsEditingTeam] = useState(false);
  const [tempTeamInput, setTempTeamInput] = useState(teamId);
  const [liveScore, setLiveScore] = useState<number>(0);
  const [liveDepth, setLiveDepth] = useState<number>(0);
  const [liveLevel, setLiveLevel] = useState<number>(1);
  const [eventLogs, setEventLogs] = useState<GameEvent[]>([]);
  const [isConsoleOpen, setIsConsoleOpen] = useState<boolean>(false);
  const [isBarCollapsed, setIsBarCollapsed] = useState<boolean>(false);
  const [iframeKey, setIframeKey] = useState<number>(1);

  const iframeRef = useRef<HTMLIFrameElement>(null);

  // Synchronize teamId changes with iframe
  useEffect(() => {
    const handleMessage = (e: MessageEvent) => {
      const data = e.data;
      if (!data) return;

      const timeStr = new Date().toLocaleTimeString();

      if (data.type === 'CROSSWORD_EVENT' || data.type === 'DIG_THE_DATA_EVENT') {
        if (data.score !== undefined) setLiveScore(data.score);
        if (data.depth !== undefined) setLiveDepth(data.depth);
        if (data.level !== undefined) setLiveLevel(data.level);

        setEventLogs((prev) => [
          {
            time: timeStr,
            type: data.type,
            action: data.action || (data.puzzleTitle ? `${data.puzzleTitle} (Solved ${data.wordsSolved}/${data.totalWords})` : undefined),
            level: data.level,
            depth: data.depth,
            score: data.score,
            teamId: data.teamId,
          },
          ...prev.slice(0, 19),
        ]);
      } else if (data.type === 'GAME_READY') {
        setEventLogs((prev) => [
          {
            time: timeStr,
            type: 'GAME_READY',
            action: 'CROSSWORD_GAME_LOADED',
          },
          ...prev.slice(0, 19),
        ]);
        // Send current teamId to game
        iframeRef.current?.contentWindow?.postMessage(
          { type: 'SET_TEAM_ID', teamId },
          '*'
        );
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [teamId]);

  const handleApplyTeamId = () => {
    const formatted = tempTeamInput.trim().toUpperCase() || 'TEAM_ALPHA';
    setTeamId(formatted);
    localStorage.setItem('dig_the_data_team_id', formatted);
    setIsEditingTeam(false);

    iframeRef.current?.contentWindow?.postMessage(
      { type: 'SET_TEAM_ID', teamId: formatted },
      '*'
    );
  };

  const handleRestartGame = () => {
    setIframeKey((prev) => prev + 1);
    setLiveScore(0);
    setLiveDepth(0);
    setLiveLevel(1);
  };

  return (
    <div className="flex flex-col w-screen h-screen overflow-hidden bg-[#07090e] text-[#f0f4f8] font-sans">
      {/* LAUNCHER HEADER BAR */}
      {!isBarCollapsed ? (
        <header className="flex-shrink-0 h-12 bg-[#0d131f] border-b border-[#00e5ff]/25 px-4 flex items-center justify-between z-40 text-xs shadow-md">
          {/* Left: Launcher Brand & Game Selector */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 font-bold tracking-wider text-cyan-400">
              <Cpu className="w-4 h-4 text-cyan-400 animate-pulse" />
              <span className="font-mono text-white">PROJECT LAUNCHER</span>
            </div>

            <div className="h-4 w-px bg-white/20" />

            <div className="flex items-center gap-1">
              <span className="px-2.5 py-0.5 rounded bg-cyan-950/80 border border-cyan-500/50 text-cyan-300 font-semibold text-[11px]">
                Game 1: CROSSWORD PUZZLE
              </span>
              <span className="hidden sm:inline-block px-2 py-0.5 rounded bg-white/5 text-gray-500 text-[10px]">
                Game 2 (Standby)
              </span>
            </div>
          </div>

          {/* Center: Team ID badge */}
          <div className="flex items-center gap-2">
            <span className="text-gray-400 font-mono text-[11px] hidden md:inline">TEAM:</span>
            {isEditingTeam ? (
              <div className="flex items-center gap-1">
                <input
                  type="text"
                  value={tempTeamInput}
                  onChange={(e) => setTempTeamInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleApplyTeamId()}
                  className="bg-black/60 border border-cyan-400 px-2 py-0.5 rounded text-white font-mono text-xs uppercase w-32 focus:outline-none"
                  autoFocus
                />
                <button
                  onClick={handleApplyTeamId}
                  className="px-2 py-0.5 bg-cyan-500 hover:bg-cyan-400 text-black font-bold rounded text-[11px]"
                >
                  OK
                </button>
              </div>
            ) : (
              <button
                onClick={() => {
                  setTempTeamInput(teamId);
                  setIsEditingTeam(true);
                }}
                className="font-mono font-bold text-amber-400 hover:text-amber-300 px-2 py-0.5 rounded bg-amber-950/40 border border-amber-500/30 hover:border-amber-400 transition-colors flex items-center gap-1"
                title="Click to edit Team ID"
              >
                {teamId}
                <span className="text-[10px] opacity-60">✎</span>
              </button>
            )}

            {/* Quick Live Stats in launcher bar */}
            <div className="hidden lg:flex items-center gap-3 ml-2 font-mono text-[11px] text-gray-300">
              <span>Score: <strong className="text-cyan-400">{liveScore}</strong></span>
              <span>Words: <strong className="text-emerald-400">{liveDepth}</strong></span>
              <span>Puzzle: <strong className="text-amber-400">{liveLevel}/7</strong></span>
            </div>
          </div>

          {/* Right: Actions */}
          <div className="flex items-center gap-2">
            {/* Telemetry Console Toggle */}
            <button
              onClick={() => setIsConsoleOpen(!isConsoleOpen)}
              className={`px-2 py-1 rounded font-mono text-[11px] flex items-center gap-1 transition-colors ${
                isConsoleOpen
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/40'
                  : 'bg-black/40 text-gray-400 border border-white/10 hover:text-white'
              }`}
              title="Toggle API & Event Telemetry Inspector"
            >
              <Terminal className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Telemetry</span>
              {eventLogs.length > 0 && (
                <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
              )}
            </button>

            {/* Reset Game */}
            <button
              onClick={handleRestartGame}
              className="p-1 rounded bg-black/40 text-gray-400 border border-white/10 hover:text-white hover:border-white/30 transition-colors"
              title="Restart Game 1"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>

            {/* Open Standalone Game */}
            <a
              href={`/games/game1/index.html?teamId=${encodeURIComponent(teamId)}`}
              target="_blank"
              rel="noreferrer"
              className="p-1 rounded bg-black/40 text-gray-400 border border-white/10 hover:text-white hover:border-white/30 transition-colors"
              title="Open Standalone Game in New Tab"
            >
              <ExternalLink className="w-3.5 h-3.5" />
            </a>

            {/* Collapse Launcher Bar */}
            <button
              onClick={() => setIsBarCollapsed(true)}
              className="p-1 text-gray-400 hover:text-white"
              title="Collapse launcher bar (Immersive Mode)"
            >
              <ChevronUp className="w-4 h-4" />
            </button>
          </div>
        </header>
      ) : (
        /* Minimized launcher pill */
        <button
          onClick={() => setIsBarCollapsed(false)}
          className="absolute top-2 right-4 z-50 px-2.5 py-1 rounded-full bg-black/80 backdrop-blur border border-cyan-500/40 text-cyan-400 text-xs font-mono flex items-center gap-1 shadow-lg hover:bg-cyan-950 transition-colors"
        >
          <span>Launcher Bar</span>
          <ChevronDown className="w-3.5 h-3.5" />
        </button>
      )}

      {/* TELEMETRY DRAWER */}
      {isConsoleOpen && !isBarCollapsed && (
        <div className="flex-shrink-0 max-h-36 overflow-y-auto bg-black/95 border-b border-cyan-500/30 p-2 font-mono text-[11px] text-gray-300">
          <div className="flex items-center justify-between text-gray-400 mb-1 pb-1 border-b border-white/10">
            <span className="text-cyan-400 font-bold flex items-center gap-1">
              <Terminal className="w-3 h-3" /> LAUNCHER & API TELEMETRY LOGS (Game 1 / {teamId})
            </span>
            <button
              onClick={() => setEventLogs([])}
              className="text-gray-500 hover:text-gray-300 text-[10px]"
            >
              Clear Logs
            </button>
          </div>
          {eventLogs.length === 0 ? (
            <div className="text-gray-600 italic py-1">Waiting for game events... (Solve words or complete puzzles)</div>
          ) : (
            <div className="space-y-1">
              {eventLogs.map((log, i) => (
                <div key={i} className="flex items-center gap-2">
                  <span className="text-gray-500">{log.time}</span>
                  <span className="text-emerald-400 font-semibold">[{log.type}]</span>
                  <span className="text-amber-300">{log.action}</span>
                  {log.score !== undefined && <span>Score: <b className="text-white">{log.score}</b></span>}
                  {log.depth !== undefined && <span>Words: <b className="text-emerald-400">{log.depth}</b></span>}
                  {log.level !== undefined && <span>Puzzle: <b className="text-purple-300">{log.level}</b></span>}
                  <CheckCircle2 className="w-3 h-3 text-emerald-400 ml-auto" />
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* EMBEDDED GAME 1 VIEWPORT */}
      <main className="flex-1 w-full h-full relative">
        <iframe
          key={iframeKey}
          ref={iframeRef}
          src={`/games/game1/index.html?teamId=${encodeURIComponent(teamId)}`}
          title="Quick Mini Crossword"
          className="w-full h-full border-0 block"
          allow="fullscreen"
        />
      </main>
    </div>
  );
}
